<?php

namespace App\Http\Livewire;

use Livewire\Component;

class SupplierCrud extends Component
{
    public function render()
    {
        return view('livewire.supplier-crud');
    }
}
